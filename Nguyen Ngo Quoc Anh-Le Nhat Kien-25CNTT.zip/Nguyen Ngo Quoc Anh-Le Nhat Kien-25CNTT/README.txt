#  Chinook Digital Music Store Management System

An advanced Enterprise Desktop Application built on the Java SE Platform implementing strict Object-Oriented Programming (OOP) architectures and GoF Design Patterns, connected to a relational MySQL database.

---

##  Authors (Class 25CNTT)
*   **Nguyễn Ngô Quốc Anh** (ID: 97482503603) — *Team Leader & Lead Backend Developer*
*   **Lê Nhật Kiên** (ID: 97482503611) — *Core Developer & QA Automation Tester*
*   **Course:** Object-Oriented Programming with Java (ITE23005)
*   **Instructor:** TS. Lê Ngọc Hiếu
*   **Defense Date:** May 29, 2026

---

##  Key Technical Features
*   **Three-Tier Architecture:** Complete separation of concerns between Presentation (Java Swing GUI), Data Access Object (DAO), and Database layers.
*   **GoF Design Patterns:** 
    *   *Singleton Registry:* Centralized single-instance management for global database configuration pipelines.
    *   *Generic DAO:* Interface-driven abstract framework (`CrudDAO<T, ID>`) ensuring reusable, typesafe operations across multiple business domains.
*   **Modern Java Integration:** Implements shallow immutable **Java Records (Java 14+)** to guarantee safe memory data states and leverages functional **Stream APIs** for fast runtime collection filtering.
*   **Security Layer:** Plaintext login credentials are raw intercepted and transformed using the **SHA-256 secure hashing algorithm** before target database validation checks.
*   **Executive Dashboard:** Renders dynamic data visualization metrics (Total Revenue, Track distribution, Top Performance Genres) asynchronously using **JFreeChart** inside standalone `SwingWorker` threads.
*   **Automated Export Reporting:** Direct extraction mechanics writing custom UI `JTable` matrix parameters natively into Microsoft Excel format (`.xlsx`) via **Apache POI**.
*   **Quality Assurance:** Regulates system baseline integrations using automated **JUnit 5 Unit Tests**.

---

##  Tech Stack & Dependencies
*   **Language:** Java SE (Recommended version: 11 or 17)
*   **Build Tool:** Maven (Project Object Model architecture)
*   **Database:** MySQL Server 8.0+
*   **UI Framework:** Java Swing Core (Cross-Platform Look and Feel)
*   **Key Libraries:** `mysql-connector-j`, `jfreechart`, `poi-ooxml`, `junit-jupiter-api`

---

## 📦 Database Setup Instructions

Before running the application, you must initialize the relational backend system.

1. Open **MySQL Workbench** or your preferred database client.
2. Execute the database structural script (`Chinook_MySql.sql`) to create the schemas, tables, and functional constraint properties.
3. Execute the data seeding script (`Chinook_MySql.sql`) to inject pre-configured transactional entries, digital tracks, and default system user authentication tokens.

```sql
-- Ensure your connection variables inside application.properties match your local instance:
db.url=jdbc:mysql://localhost:3306/chinook
db.username=YOUR_MYSQL_USER
db.password=YOUR_MYSQL_PASSWORD