-- ============================================================
-- Project: Chinook Music Store Management System
-- Course : Object-Oriented Programming with Java
-- DBMS   : MySQL 8+
-- Purpose: Database schema for Java Swing + JDBC + OOP Final Project
-- ============================================================

DROP DATABASE IF EXISTS chinook_music_store;

CREATE DATABASE chinook_music_store
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE chinook_music_store;

-- ============================================================
-- 1. AUTHENTICATION & ROLE-BASED ACCESS CONTROL
-- ============================================================

CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255)
);

CREATE TABLE app_users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role_id INT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_app_users_role
        FOREIGN KEY (role_id)
        REFERENCES roles(role_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

-- ============================================================
-- 2. CHINOOK CORE DOMAIN TABLES
-- ============================================================

CREATE TABLE artists (
    artist_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,

    CONSTRAINT uq_artists_name UNIQUE (name)
);

CREATE TABLE albums (
    album_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    artist_id INT NOT NULL,

    CONSTRAINT fk_albums_artist
        FOREIGN KEY (artist_id)
        REFERENCES artists(artist_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE TABLE genres (
    genre_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,

    CONSTRAINT uq_genres_name UNIQUE (name)
);

CREATE TABLE media_types (
    media_type_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,

    CONSTRAINT uq_media_types_name UNIQUE (name)
);

CREATE TABLE tracks (
    track_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    album_id INT NULL,
    media_type_id INT NOT NULL,
    genre_id INT NULL,
    composer VARCHAR(220),
    milliseconds INT NOT NULL,
    bytes INT,
    unit_price DECIMAL(10, 2) NOT NULL DEFAULT 0.99,

    CONSTRAINT fk_tracks_album
        FOREIGN KEY (album_id)
        REFERENCES albums(album_id)
        ON UPDATE CASCADE
        ON DELETE SET NULL,

    CONSTRAINT fk_tracks_media_type
        FOREIGN KEY (media_type_id)
        REFERENCES media_types(media_type_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_tracks_genre
        FOREIGN KEY (genre_id)
        REFERENCES genres(genre_id)
        ON UPDATE CASCADE
        ON DELETE SET NULL,

    CONSTRAINT chk_tracks_milliseconds
        CHECK (milliseconds > 0),

    CONSTRAINT chk_tracks_bytes
        CHECK (bytes IS NULL OR bytes >= 0),

    CONSTRAINT chk_tracks_unit_price
        CHECK (unit_price >= 0)
);

CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(40) NOT NULL,
    last_name VARCHAR(40) NOT NULL,
    company VARCHAR(80),
    address VARCHAR(120),
    city VARCHAR(60),
    state VARCHAR(40),
    country VARCHAR(40),
    postal_code VARCHAR(20),
    phone VARCHAR(30),
    email VARCHAR(100) NOT NULL,

    CONSTRAINT uq_customers_email UNIQUE (email)
);

CREATE TABLE invoices (
    invoice_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    invoice_date DATETIME NOT NULL,
    billing_address VARCHAR(120),
    billing_city VARCHAR(60),
    billing_state VARCHAR(40),
    billing_country VARCHAR(40),
    billing_postal_code VARCHAR(20),
    total DECIMAL(10, 2) NOT NULL DEFAULT 0,

    CONSTRAINT fk_invoices_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_invoices_total
        CHECK (total >= 0)
);

CREATE TABLE invoice_lines (
    invoice_line_id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    track_id INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,

    CONSTRAINT fk_invoice_lines_invoice
        FOREIGN KEY (invoice_id)
        REFERENCES invoices(invoice_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_invoice_lines_track
        FOREIGN KEY (track_id)
        REFERENCES tracks(track_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_invoice_lines_unit_price
        CHECK (unit_price >= 0),

    CONSTRAINT chk_invoice_lines_quantity
        CHECK (quantity > 0)
);

-- ============================================================
-- 3. INDEXES FOR SEARCH, FILTER, SORT, PAGINATION
-- ============================================================

CREATE INDEX idx_app_users_username ON app_users(username);
CREATE INDEX idx_app_users_role_id ON app_users(role_id);

CREATE INDEX idx_albums_artist_id ON albums(artist_id);

CREATE INDEX idx_tracks_name ON tracks(name);
CREATE INDEX idx_tracks_album_id ON tracks(album_id);
CREATE INDEX idx_tracks_genre_id ON tracks(genre_id);
CREATE INDEX idx_tracks_media_type_id ON tracks(media_type_id);
CREATE INDEX idx_tracks_unit_price ON tracks(unit_price);

CREATE INDEX idx_customers_country ON customers(country);
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_name ON customers(last_name, first_name);

CREATE INDEX idx_invoices_customer_id ON invoices(customer_id);
CREATE INDEX idx_invoices_invoice_date ON invoices(invoice_date);
CREATE INDEX idx_invoices_billing_country ON invoices(billing_country);

CREATE INDEX idx_invoice_lines_invoice_id ON invoice_lines(invoice_id);
CREATE INDEX idx_invoice_lines_track_id ON invoice_lines(track_id);

-- ============================================================
-- 4. SEED DATA FOR ROLES AND USERS
-- Password demo:
-- admin123, staff123, viewer123
-- Hash is generated by MySQL SHA2().
-- In Java app, you should also hash password before checking login.
-- ============================================================

INSERT INTO roles (role_name, description) VALUES
('ADMIN', 'Full access to all system features'),
('STAFF', 'Can manage music store data and view dashboard'),
('VIEWER', 'Read-only access');

INSERT INTO app_users (
    username,
    password_hash,
    full_name,
    email,
    role_id,
    is_active
) VALUES
('admin', SHA2('admin123', 256), 'System Administrator', 'admin@chinook.local', 1, TRUE),
('staff', SHA2('staff123', 256), 'Store Staff', 'staff@chinook.local', 2, TRUE),
('viewer', SHA2('viewer123', 256), 'Demo Viewer', 'viewer@chinook.local', 3, TRUE);

-- ============================================================
-- 5. SAMPLE CHINOOK DATA
-- Có thể xóa phần này nếu bạn import dataset Chinook thật từ GitHub.
-- Phần này chỉ để test nhanh app, CRUD, search, chart.
-- ============================================================

INSERT INTO artists (name) VALUES
('AC/DC'),
('Queen'),
('Metallica'),
('Nirvana'),
('The Beatles');

INSERT INTO albums (title, artist_id) VALUES
('Back In Black', 1),
('A Night at the Opera', 2),
('Master of Puppets', 3),
('Nevermind', 4),
('Abbey Road', 5);

INSERT INTO genres (name) VALUES
('Rock'),
('Metal'),
('Alternative'),
('Pop');

INSERT INTO media_types (name) VALUES
('MPEG audio file'),
('Protected AAC audio file'),
('AAC audio file');

INSERT INTO tracks (
    name,
    album_id,
    media_type_id,
    genre_id,
    composer,
    milliseconds,
    bytes,
    unit_price
) VALUES
('Hells Bells', 1, 1, 1, 'Angus Young, Malcolm Young, Brian Johnson', 312000, 10000000, 0.99),
('Back In Black', 1, 1, 1, 'Angus Young, Malcolm Young, Brian Johnson', 255000, 9000000, 0.99),
('Bohemian Rhapsody', 2, 1, 1, 'Freddie Mercury', 354000, 12000000, 1.29),
('Master of Puppets', 3, 1, 2, 'Metallica', 515000, 15000000, 1.29),
('Smells Like Teen Spirit', 4, 1, 3, 'Kurt Cobain, Krist Novoselic, Dave Grohl', 301000, 11000000, 0.99),
('Come Together', 5, 1, 4, 'John Lennon, Paul McCartney', 259000, 9500000, 0.99);

INSERT INTO customers (
    first_name,
    last_name,
    company,
    address,
    city,
    state,
    country,
    postal_code,
    phone,
    email
) VALUES
('John', 'Smith', 'Smith Music Ltd.', '123 Main Street', 'New York', 'NY', 'USA', '10001', '+1 555 1111', 'john.smith@example.com'),
('Emma', 'Brown', NULL, '45 Queen Street', 'London', NULL, 'United Kingdom', 'SW1A', '+44 555 2222', 'emma.brown@example.com'),
('Minh', 'Nguyen', NULL, '12 Nguyen Hue', 'Ho Chi Minh City', NULL, 'Vietnam', '700000', '+84 555 3333', 'minh.nguyen@example.com');

INSERT INTO invoices (
    customer_id,
    invoice_date,
    billing_address,
    billing_city,
    billing_state,
    billing_country,
    billing_postal_code,
    total
) VALUES
(1, '2026-01-15 10:30:00', '123 Main Street', 'New York', 'NY', 'USA', '10001', 2.28),
(2, '2026-02-20 14:00:00', '45 Queen Street', 'London', NULL, 'United Kingdom', 'SW1A', 1.29),
(3, '2026-03-05 09:15:00', '12 Nguyen Hue', 'Ho Chi Minh City', NULL, 'Vietnam', '700000', 1.98),
(1, '2026-04-10 16:45:00', '123 Main Street', 'New York', 'NY', 'USA', '10001', 0.99);

INSERT INTO invoice_lines (
    invoice_id,
    track_id,
    unit_price,
    quantity
) VALUES
(1, 1, 0.99, 1),
(1, 3, 1.29, 1),
(2, 4, 1.29, 1),
(3, 5, 0.99, 1),
(3, 6, 0.99, 1),
(4, 2, 0.99, 1);

-- ============================================================
-- 6. VIEWS FOR JTABLE, DASHBOARD, CHARTS
-- ============================================================

CREATE VIEW vw_track_details AS
SELECT
    t.track_id,
    t.name AS track_name,
    al.album_id,
    al.title AS album_title,
    ar.artist_id,
    ar.name AS artist_name,
    g.genre_id,
    g.name AS genre_name,
    mt.media_type_id,
    mt.name AS media_type,
    t.composer,
    t.milliseconds,
    t.bytes,
    t.unit_price
FROM tracks t
LEFT JOIN albums al ON t.album_id = al.album_id
LEFT JOIN artists ar ON al.artist_id = ar.artist_id
LEFT JOIN genres g ON t.genre_id = g.genre_id
LEFT JOIN media_types mt ON t.media_type_id = mt.media_type_id;

CREATE VIEW vw_invoice_details AS
SELECT
    i.invoice_id,
    i.invoice_date,
    c.customer_id,
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    c.email AS customer_email,
    i.billing_country,
    i.billing_city,
    i.total
FROM invoices i
JOIN customers c ON i.customer_id = c.customer_id;

CREATE VIEW vw_monthly_revenue AS
SELECT
    DATE_FORMAT(invoice_date, '%Y-%m') AS revenue_month,
    SUM(total) AS total_revenue,
    COUNT(invoice_id) AS invoice_count
FROM invoices
GROUP BY DATE_FORMAT(invoice_date, '%Y-%m')
ORDER BY revenue_month;

CREATE VIEW vw_genre_sales AS
SELECT
    g.genre_id,
    g.name AS genre_name,
    SUM(il.unit_price * il.quantity) AS total_sales,
    SUM(il.quantity) AS total_items_sold
FROM invoice_lines il
JOIN tracks t ON il.track_id = t.track_id
LEFT JOIN genres g ON t.genre_id = g.genre_id
GROUP BY g.genre_id, g.name
ORDER BY total_sales DESC;

CREATE VIEW vw_country_revenue AS
SELECT
    billing_country,
    SUM(total) AS total_revenue,
    COUNT(invoice_id) AS invoice_count
FROM invoices
WHERE billing_country IS NOT NULL
GROUP BY billing_country
ORDER BY total_revenue DESC;

CREATE VIEW vw_kpi_summary AS
SELECT
    (SELECT COUNT(*) FROM tracks) AS total_tracks,
    (SELECT COUNT(*) FROM customers) AS total_customers,
    (SELECT COUNT(*) FROM invoices) AS total_invoices,
    (SELECT COALESCE(SUM(total), 0) FROM invoices) AS total_revenue,
    (SELECT COALESCE(AVG(total), 0) FROM invoices) AS average_invoice_value;

-- ============================================================
-- 7. TEST QUERIES
-- Chạy thử sau khi execute script.
-- ============================================================

SELECT * FROM roles;
SELECT username, full_name, email, role_id, is_active FROM app_users;

SELECT * FROM vw_track_details;
SELECT * FROM vw_monthly_revenue;
SELECT * FROM vw_genre_sales;
SELECT * FROM vw_country_revenue;
SELECT * FROM vw_kpi_summary;