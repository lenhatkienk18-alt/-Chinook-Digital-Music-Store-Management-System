# Chinook Music Store Management System

Java Swing + MySQL JDBC + MVC + DAO + Service project for the OOP final assignment.

## Run database

Open MySQL Workbench and run:

```sql
SOURCE database/schema.sql;
```

## Configure connection

Edit `src/main/resources/application.properties`.

Default account:

| Role | Username | Password |
|---|---|---|
| ADMIN | admin | admin123 |
| STAFF | staff | staff123 |
| VIEWER | viewer | viewer123 |

## Run app

```bash
mvn clean compile
mvn exec:java
```

## Run tests

```bash
mvn test
```

## Architecture

```text
Swing View -> Controller -> Service -> DAO -> MySQL
```
