# Project Report Outline

## 1. Introduction
Project title, objective, dataset chosen, motivation, tools and technologies.

## 2. Group Details & Work Distribution
Full name, student ID, role of each member, collaboration summary.

## 3. Dataset Acquisition
Explain how the Chinook dataset was downloaded/imported.

## 4. System Architecture
MVC/layered architecture, DAO pattern, design patterns.

## 5. Database Design
ERD, table descriptions, indexing decisions, sample SQL queries.

## 6. System Features
Screenshots: Login, Dashboard, Artist CRUD, Album CRUD, Track CRUD, Customer CRUD, Export.

## 7. Modern Java Features Used
Records, Optional, Stream API, lambda, var, enhanced switch.

## 8. Unit Tests
Test method names, what each test validates, and coverage screenshot.

## 9. REST / Export Integration
Excel export using Apache POI.

## 10. Challenges & Reflections
Problems, solutions, lessons learned.

## 11. Conclusion & Future Work
Summary and future improvements.

## 12. References
APA 7 references for Java, MySQL, JFreeChart, Apache POI, JUnit, AI tools if used.
