/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Track CRUD panel with search/filter, JTable sorting, and Excel export.
 */

package com.chinook.view;

import com.chinook.controller.TrackController;
import com.chinook.dto.TrackDTO;
import com.chinook.event.DataChangeNotifier;
import com.chinook.model.Track;
import com.chinook.service.ExportService;
import com.chinook.util.DialogUtil;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.io.File; import java.math.BigDecimal; import java.util.List;

public class TrackPanel extends JPanel {
    private final TrackController controller; private final ExportService exporter; private final DataChangeNotifier notifier; private final boolean canWrite;
    private final JTextField search=new JTextField(14), genreFilter=new JTextField(5), id=new JTextField(5), name=new JTextField(14), albumId=new JTextField(5), mediaTypeId=new JTextField("1",5), genreId=new JTextField(5), composer=new JTextField(12), ms=new JTextField("180000",7), bytes=new JTextField(7), price=new JTextField("0.99",5);
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","Track","Album","Artist","Genre ID","Genre","Media","Composer","Ms","Bytes","Price"},0); private final JTable table=new JTable(model);
    public TrackPanel(TrackController controller, ExportService exporter, DataChangeNotifier notifier, boolean canWrite){
        this.controller=controller; this.exporter=exporter; this.notifier=notifier; this.canWrite=canWrite; setLayout(new BorderLayout(8,8)); add(top(),BorderLayout.NORTH); add(new JScrollPane(table),BorderLayout.CENTER); add(form(),BorderLayout.SOUTH); table.setAutoCreateRowSorter(true); id.setEditable(false); table.getSelectionModel().addListSelectionListener(e->select()); load();
    }
    private JPanel top(){ JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT)); JButton find=new JButton("Search"), refresh=new JButton("Refresh"), export=new JButton("Export Excel"); find.addActionListener(e->load()); refresh.addActionListener(e->{search.setText("");genreFilter.setText("");load();}); export.addActionListener(e->export()); p.add(new JLabel("Keyword:"));p.add(search);p.add(new JLabel("Genre ID:"));p.add(genreFilter);p.add(find);p.add(refresh);p.add(export);return p;}
    private JPanel form(){ JPanel box=new JPanel(new GridLayout(3,1)); JPanel r1=new JPanel(new FlowLayout(FlowLayout.LEFT)); JPanel r2=new JPanel(new FlowLayout(FlowLayout.LEFT)); JPanel r3=new JPanel(new FlowLayout(FlowLayout.LEFT)); r1.add(new JLabel("ID:"));r1.add(id);r1.add(new JLabel("Name:"));r1.add(name);r1.add(new JLabel("Album ID:"));r1.add(albumId);r1.add(new JLabel("MediaType ID:"));r1.add(mediaTypeId);r1.add(new JLabel("Genre ID:"));r1.add(genreId); r2.add(new JLabel("Composer:"));r2.add(composer);r2.add(new JLabel("Ms:"));r2.add(ms);r2.add(new JLabel("Bytes:"));r2.add(bytes);r2.add(new JLabel("Price:"));r2.add(price); JButton add=new JButton("Add"), update=new JButton("Update"), del=new JButton("Delete"); add.setEnabled(canWrite);update.setEnabled(canWrite);del.setEnabled(canWrite); add.addActionListener(e->add());update.addActionListener(e->update());del.addActionListener(e->delete()); r3.add(add);r3.add(update);r3.add(del); box.add(r1);box.add(r2);box.add(r3); return box; }
    private void load(){ new SwingWorker<List<TrackDTO>,Void>(){ protected List<TrackDTO> doInBackground() throws Exception { return controller.search(search.getText(), intOrNull(genreFilter.getText()),1,50); } protected void done(){ try{ model.setRowCount(0); for(TrackDTO t:get()) model.addRow(new Object[]{t.trackId(),t.trackName(),t.albumTitle(),t.artistName(),t.genreId(),t.genreName(),t.mediaType(),t.composer(),t.milliseconds(),t.bytes(),t.unitPrice()}); }catch(Exception ex){DialogUtil.error(TrackPanel.this,ex.getMessage());} } }.execute(); }
    private void add(){ try{ controller.create(read(false)); clear(); load(); notifier.notifyDataChanged(); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void update(){ try{ controller.update(read(true)); clear(); load(); notifier.notifyDataChanged(); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void delete(){ try{ int x=Integer.parseInt(id.getText()); if(DialogUtil.confirm(this,"Delete selected track?")){ controller.delete(x); clear(); load(); notifier.notifyDataChanged(); } }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private Track read(boolean hasId){ Track t=new Track(name.getText(), intOrNull(albumId.getText()), Integer.parseInt(mediaTypeId.getText()), intOrNull(genreId.getText()), composer.getText(), Integer.parseInt(ms.getText()), intOrNull(bytes.getText()), new BigDecimal(price.getText())); if(hasId)t.setId(Integer.parseInt(id.getText())); return t; }
    private Integer intOrNull(String s){ return s==null||s.isBlank()?null:Integer.parseInt(s.trim()); }
    private void select(){ int r=table.getSelectedRow(); if(r<0)return; int m=table.convertRowIndexToModel(r); id.setText(v(m,0)); name.setText(v(m,1)); genreId.setText(v(m,4)); composer.setText(v(m,7)); ms.setText(v(m,8)); bytes.setText(v(m,9)); price.setText(v(m,10)); }
    private String v(int r,int c){ Object x=model.getValueAt(r,c); return x==null?"":x.toString(); }
    private void clear(){ id.setText(""); name.setText(""); albumId.setText(""); mediaTypeId.setText("1"); genreId.setText(""); composer.setText(""); ms.setText("180000"); bytes.setText(""); price.setText("0.99"); }
    private void export(){ try{ File f=new File("tracks.xlsx"); exporter.exportTable(table,f,"Tracks"); DialogUtil.info(this,"Exported: "+f.getAbsolutePath()); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
}
