/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Domain model for albums.
 */

package com.chinook.model;

public class Album extends BaseEntity {
    private String title;
    private int artistId;
    public Album() { }
    public Album(String title, int artistId) { this.title = title; this.artistId = artistId; }
    public Album(int id, String title, int artistId) { super(id); this.title = title; this.artistId = artistId; }
    public String getTitle() { return title; }
    public int getArtistId() { return artistId; }
    public void setTitle(String title) { this.title = title; }
    public void setArtistId(int artistId) { this.artistId = artistId; }
}
