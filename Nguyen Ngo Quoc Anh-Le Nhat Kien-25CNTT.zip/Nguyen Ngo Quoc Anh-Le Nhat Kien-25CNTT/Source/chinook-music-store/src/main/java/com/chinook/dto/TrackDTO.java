/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Immutable DTO for joined track table data.
 */

package com.chinook.dto;
import java.math.BigDecimal;
public record TrackDTO(int trackId, String trackName, Integer albumId, String albumTitle, Integer artistId, String artistName,
                       Integer genreId, String genreName, Integer mediaTypeId, String mediaType, String composer,
                       int milliseconds, Integer bytes, BigDecimal unitPrice) { }
