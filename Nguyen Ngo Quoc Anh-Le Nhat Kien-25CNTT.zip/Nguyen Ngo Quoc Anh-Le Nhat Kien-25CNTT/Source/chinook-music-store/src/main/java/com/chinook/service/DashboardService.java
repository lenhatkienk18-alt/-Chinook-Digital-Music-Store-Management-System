/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Business service for dashboard KPI and chart data.
 */

package com.chinook.service;
import com.chinook.dao.DashboardDAO; import com.chinook.dto.*; import java.util.*;
public class DashboardService {
    private final DashboardDAO dao; public DashboardService(DashboardDAO dao){this.dao=dao;}
    public KpiSummaryDTO getKpiSummary()throws Exception{return dao.getKpiSummary();}
    public List<RevenueDTO> getMonthlyRevenue()throws Exception{return dao.getMonthlyRevenue();}
    public List<GenreSalesDTO> getTopGenres(int limit)throws Exception{return dao.getTopGenres(limit).stream().limit(limit).toList();}
}
