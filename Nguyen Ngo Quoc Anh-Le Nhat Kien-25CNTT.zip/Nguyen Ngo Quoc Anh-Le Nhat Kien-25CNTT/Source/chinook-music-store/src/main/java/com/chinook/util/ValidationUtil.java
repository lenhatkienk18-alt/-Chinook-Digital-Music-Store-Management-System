/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Common validation helper used by service classes.
 */

package com.chinook.util;

import com.chinook.exception.*;
import java.math.BigDecimal;

public final class ValidationUtil {
    private ValidationUtil() { }
    public static void requireNotBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) throw new AppException(ErrorCode.VALIDATION_ERROR, fieldName + " must not be blank.");
    }
    public static void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new AppException(ErrorCode.VALIDATION_ERROR, fieldName + " must be positive.");
    }
    public static void requireNonNegative(BigDecimal value, String fieldName) {
        if (value == null || value.compareTo(BigDecimal.ZERO) < 0) throw new AppException(ErrorCode.VALIDATION_ERROR, fieldName + " must not be negative.");
    }
    public static void requireEmail(String email) {
        requireNotBlank(email, "Email");
        if (!email.contains("@") || !email.contains(".")) throw new AppException(ErrorCode.VALIDATION_ERROR, "Email format is invalid.");
    }
}
