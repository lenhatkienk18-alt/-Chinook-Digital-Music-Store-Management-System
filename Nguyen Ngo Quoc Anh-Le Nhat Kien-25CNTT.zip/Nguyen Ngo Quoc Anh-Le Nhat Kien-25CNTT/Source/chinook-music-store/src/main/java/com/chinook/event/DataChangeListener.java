/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Observer interface for chart refresh events.
 */

package com.chinook.event;
public interface DataChangeListener { void onDataChanged(); }
