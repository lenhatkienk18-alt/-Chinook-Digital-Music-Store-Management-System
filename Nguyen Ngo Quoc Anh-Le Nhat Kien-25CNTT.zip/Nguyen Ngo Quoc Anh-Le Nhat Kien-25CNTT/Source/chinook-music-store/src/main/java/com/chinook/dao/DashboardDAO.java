/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: JDBC DAO for dashboard KPI and chart queries.
 */

package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.dto.*;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public class DashboardDAO {
    public KpiSummaryDTO getKpiSummary() throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM vw_kpi_summary"); ResultSet rs=ps.executeQuery()){
            if(rs.next()) return new KpiSummaryDTO(rs.getInt("total_tracks"), rs.getInt("total_customers"), rs.getInt("total_invoices"), nz(rs.getBigDecimal("total_revenue")), nz(rs.getBigDecimal("average_invoice_value")));
        }
        return new KpiSummaryDTO(0,0,0,BigDecimal.ZERO,BigDecimal.ZERO);
    }
    public List<RevenueDTO> getMonthlyRevenue() throws Exception {
        List<RevenueDTO> list=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("SELECT revenue_month,total_revenue FROM vw_monthly_revenue ORDER BY revenue_month"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) list.add(new RevenueDTO(rs.getString("revenue_month"), nz(rs.getBigDecimal("total_revenue"))));
        }
        return list;
    }
    public List<GenreSalesDTO> getTopGenres(int limit) throws Exception {
        List<GenreSalesDTO> list=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("SELECT genre_name,total_sales,total_items_sold FROM vw_genre_sales ORDER BY total_sales DESC LIMIT ?")){
            ps.setInt(1,limit); try(ResultSet rs=ps.executeQuery()){ while(rs.next()) list.add(new GenreSalesDTO(rs.getString("genre_name"), nz(rs.getBigDecimal("total_sales")), rs.getInt("total_items_sold"))); }
        }
        return list;
    }
    private BigDecimal nz(BigDecimal value){ return value==null?BigDecimal.ZERO:value; }
}
