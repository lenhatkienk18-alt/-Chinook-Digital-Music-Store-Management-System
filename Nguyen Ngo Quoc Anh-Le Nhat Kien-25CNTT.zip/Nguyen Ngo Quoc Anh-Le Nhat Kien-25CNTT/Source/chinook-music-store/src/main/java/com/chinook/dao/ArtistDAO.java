/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: JDBC DAO for Artist CRUD.
 */

package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.model.Artist;
import java.sql.*;
import java.util.*;

public class ArtistDAO implements CrudDAO<Artist, Integer> {
    public Optional<Artist> findById(Integer id) throws Exception {
        String sql = "SELECT artist_id, name FROM artists WHERE artist_id=?";
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? Optional.of(map(rs)) : Optional.empty(); }
        }
    }
    public List<Artist> findAll(int page, int pageSize) throws Exception { return searchByName("", page, pageSize); }
    public List<Artist> searchByName(String keyword, int page, int pageSize) throws Exception {
        String sql = "SELECT artist_id, name FROM artists WHERE name LIKE ? ORDER BY artist_id LIMIT ? OFFSET ?";
        List<Artist> list = new ArrayList<>(); int offset = (page - 1) * pageSize;
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%"); ps.setInt(2, pageSize); ps.setInt(3, offset);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        }
        return list;
    }
    public void save(Artist a) throws Exception {
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement("INSERT INTO artists(name) VALUES(?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, a.getName()); ps.executeUpdate(); try (ResultSet keys = ps.getGeneratedKeys()) { if (keys.next()) a.setId(keys.getInt(1)); }
        }
    }
    public void update(Artist a) throws Exception {
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE artists SET name=? WHERE artist_id=?")) {
            ps.setString(1, a.getName()); ps.setInt(2, a.getId()); ps.executeUpdate();
        }
    }
    public void delete(Integer id) throws Exception {
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM artists WHERE artist_id=?")) {
            ps.setInt(1, id); ps.executeUpdate();
        }
    }
    private Artist map(ResultSet rs) throws Exception { return new Artist(rs.getInt("artist_id"), rs.getString("name")); }
}
