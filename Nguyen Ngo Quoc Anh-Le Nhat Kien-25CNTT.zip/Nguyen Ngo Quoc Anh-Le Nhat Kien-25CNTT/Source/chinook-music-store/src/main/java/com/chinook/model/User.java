/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Domain model for application users.
 */

package com.chinook.model;

import java.time.LocalDateTime;

public class User extends BaseEntity {
    private String username, passwordHash, fullName, email;
    private Role role;
    private boolean active;
    private LocalDateTime lastLogin;
    public User(int id, String username, String passwordHash, String fullName, String email, Role role, boolean active, LocalDateTime lastLogin) {
        super(id); this.username = username; this.passwordHash = passwordHash; this.fullName = fullName; this.email = email;
        this.role = role; this.active = active; this.lastLogin = lastLogin;
    }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public Role getRole() { return role; }
    public boolean isActive() { return active; }
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
}
