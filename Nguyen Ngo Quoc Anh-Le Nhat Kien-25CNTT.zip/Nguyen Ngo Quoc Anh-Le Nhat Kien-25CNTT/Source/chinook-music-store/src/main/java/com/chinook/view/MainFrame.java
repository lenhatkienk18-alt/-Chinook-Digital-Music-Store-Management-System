/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Main application window with role-based tabs.
 */

package com.chinook.view;

import com.chinook.controller.*;
import com.chinook.dao.*;
import com.chinook.dto.UserDTO;
import com.chinook.event.DataChangeNotifier;
import com.chinook.service.*;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final String token; private final UserDTO user; private final AuthService auth; private final SessionService sessions;
    public MainFrame(String token, UserDTO user, AuthService auth, SessionService sessions){
        this.token=token; this.user=user; this.auth=auth; this.sessions=sessions;
        setTitle("Chinook Music Store - " + user.fullName() + " (" + user.role() + ")"); setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(1150,760); setLocationRelativeTo(null); setLayout(new BorderLayout());
        add(top(), BorderLayout.NORTH); add(tabs(), BorderLayout.CENTER);
    }
    private JPanel top(){ JPanel p=new JPanel(new BorderLayout()); p.setBorder(BorderFactory.createEmptyBorder(8,12,8,12)); p.add(new JLabel("Logged in: "+user.fullName()+" | Role: "+user.role()), BorderLayout.WEST); JButton logout=new JButton("Logout"); logout.addActionListener(e->{auth.logout(token); new LoginFrame().setVisible(true); dispose();}); p.add(logout,BorderLayout.EAST); return p; }
    private JTabbedPane tabs(){
        boolean canWrite = sessions.canWrite(user.role()); DataChangeNotifier notifier = new DataChangeNotifier(); JTabbedPane tabs = new JTabbedPane();
        DashboardPanel dashboard = new DashboardPanel(new DashboardController(new DashboardService(new DashboardDAO()))); notifier.addListener(dashboard);
        tabs.addTab("Dashboard", dashboard);
        tabs.addTab("Artists", new ArtistPanel(new ArtistController(new ArtistService(new ArtistDAO())), new ExportService(), notifier, canWrite));
        tabs.addTab("Albums", new AlbumPanel(new AlbumController(new AlbumService(new AlbumDAO())), new ExportService(), notifier, canWrite));
        tabs.addTab("Tracks", new TrackPanel(new TrackController(new TrackService(new TrackDAO())), new ExportService(), notifier, canWrite));
        tabs.addTab("Customers", new CustomerPanel(new CustomerController(new CustomerService(new CustomerDAO())), new ExportService(), notifier, canWrite));
        tabs.addTab("Profile", new ProfilePanel(token, user, auth));
        return tabs;
    }
}
