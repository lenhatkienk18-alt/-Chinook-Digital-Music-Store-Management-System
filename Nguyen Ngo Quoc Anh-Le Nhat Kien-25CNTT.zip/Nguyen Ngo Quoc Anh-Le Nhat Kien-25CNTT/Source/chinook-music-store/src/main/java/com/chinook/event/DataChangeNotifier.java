/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Observer notifier for data change events.
 */

package com.chinook.event;
import java.util.*;
public class DataChangeNotifier {
    private final List<DataChangeListener> listeners = new ArrayList<>();
    public void addListener(DataChangeListener listener) { listeners.add(listener); }
    public void notifyDataChanged() { listeners.forEach(DataChangeListener::onDataChanged); }
}
