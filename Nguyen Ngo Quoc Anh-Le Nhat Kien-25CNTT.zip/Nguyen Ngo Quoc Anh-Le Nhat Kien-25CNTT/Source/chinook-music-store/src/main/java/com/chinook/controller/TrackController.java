/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Controller for track actions.
 */

package com.chinook.controller;
import com.chinook.dto.TrackDTO; import com.chinook.model.Track; import com.chinook.service.TrackService; import java.util.*;
public class TrackController { private final TrackService s; public TrackController(TrackService s){this.s=s;} public List<TrackDTO> search(String k,Integer g,int p,int z)throws Exception{return s.searchDetails(k,g,p,z);} public void create(Track t)throws Exception{s.create(t);} public void update(Track t)throws Exception{s.update(t);} public void delete(int id)throws Exception{s.delete(id);} }
