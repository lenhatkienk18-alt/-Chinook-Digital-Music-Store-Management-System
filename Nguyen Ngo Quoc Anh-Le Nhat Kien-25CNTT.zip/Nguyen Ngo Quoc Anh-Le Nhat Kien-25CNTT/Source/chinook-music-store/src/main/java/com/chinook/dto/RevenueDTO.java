/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Immutable DTO for monthly revenue chart.
 */

package com.chinook.dto;
import java.math.BigDecimal;
public record RevenueDTO(String month, BigDecimal totalRevenue) { }
