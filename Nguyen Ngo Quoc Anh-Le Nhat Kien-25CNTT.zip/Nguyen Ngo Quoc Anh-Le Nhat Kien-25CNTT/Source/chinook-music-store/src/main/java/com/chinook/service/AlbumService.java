/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Business service for Album validation and CRUD.
 */

package com.chinook.service;
import com.chinook.dao.AlbumDAO; import com.chinook.model.Album; import com.chinook.util.ValidationUtil; import java.util.*;
public class AlbumService {
    private final AlbumDAO dao; public AlbumService(AlbumDAO dao){this.dao=dao;}
    public List<Album> search(String keyword,int page,int size)throws Exception{return dao.searchByTitle(keyword==null?"":keyword,page,size);}    
    public void create(String title,int artistId)throws Exception{ValidationUtil.requireNotBlank(title,"Album title"); ValidationUtil.requirePositive(artistId,"Artist ID"); dao.save(new Album(title.trim(),artistId));}
    public void update(int id,String title,int artistId)throws Exception{ValidationUtil.requirePositive(id,"Album ID"); ValidationUtil.requireNotBlank(title,"Album title"); ValidationUtil.requirePositive(artistId,"Artist ID"); dao.update(new Album(id,title.trim(),artistId));}
    public void delete(int id)throws Exception{ValidationUtil.requirePositive(id,"Album ID"); dao.delete(id);} 
}
