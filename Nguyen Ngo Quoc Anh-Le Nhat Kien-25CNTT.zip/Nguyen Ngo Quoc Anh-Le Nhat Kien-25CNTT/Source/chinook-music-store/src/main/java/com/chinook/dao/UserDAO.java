/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: JDBC DAO for authentication.
 */

package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.model.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class UserDAO {
    public Optional<User> findByUsername(String username) throws Exception {
        String sql="SELECT u.user_id,u.username,u.password_hash,u.full_name,u.email,r.role_name,u.is_active,u.last_login FROM app_users u JOIN roles r ON u.role_id=r.role_id WHERE u.username=?";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1, username);
            try(ResultSet rs=ps.executeQuery()){
                if(!rs.next()) return Optional.empty();
                Timestamp ts=rs.getTimestamp("last_login");
                return Optional.of(new User(rs.getInt("user_id"), rs.getString("username"), rs.getString("password_hash"), rs.getString("full_name"), rs.getString("email"), Role.valueOf(rs.getString("role_name")), rs.getBoolean("is_active"), ts==null?null:ts.toLocalDateTime()));
            }
        }
    }
    public void updateLastLogin(int userId, LocalDateTime lastLogin) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("UPDATE app_users SET last_login=? WHERE user_id=?")){
            ps.setTimestamp(1, Timestamp.valueOf(lastLogin)); ps.setInt(2,userId); ps.executeUpdate();
        }
    }
    public void updatePasswordHash(int userId, String hash) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("UPDATE app_users SET password_hash=? WHERE user_id=?")){
            ps.setString(1,hash); ps.setInt(2,userId); ps.executeUpdate();
        }
    }
}
