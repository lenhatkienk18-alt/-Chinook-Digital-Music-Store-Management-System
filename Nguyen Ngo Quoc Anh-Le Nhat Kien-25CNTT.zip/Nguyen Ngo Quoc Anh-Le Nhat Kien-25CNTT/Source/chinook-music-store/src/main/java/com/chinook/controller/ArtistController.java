/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Controller for artist actions.
 */

package com.chinook.controller;
import com.chinook.model.Artist; import com.chinook.service.ArtistService; import java.util.*;
public class ArtistController { private final ArtistService s; public ArtistController(ArtistService s){this.s=s;} public List<Artist> search(String k,int p,int z)throws Exception{return s.search(k,p,z);} public void create(String n)throws Exception{s.create(n);} public void update(int id,String n)throws Exception{s.update(id,n);} public void delete(int id)throws Exception{s.delete(id);} }
