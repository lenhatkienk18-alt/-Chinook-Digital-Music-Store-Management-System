/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Business service wrapper for Excel export.
 */

package com.chinook.service;
import com.chinook.util.ExcelExporter; import javax.swing.*; import java.io.*;
public class ExportService { public void exportTable(JTable table, File file, String sheetName)throws Exception{ExcelExporter.exportTableToXlsx(table,file,sheetName);} }
