/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Business service for Track validation, search, filter, and CRUD.
 */

package com.chinook.service;
import com.chinook.dao.TrackDAO; import com.chinook.dto.TrackDTO; import com.chinook.model.Track; import com.chinook.util.ValidationUtil; import java.util.*;
public class TrackService {
    private final TrackDAO dao; public TrackService(TrackDAO dao){this.dao=dao;}
    public List<TrackDTO> searchDetails(String keyword,Integer genreId,int page,int size)throws Exception{return dao.searchDetails(keyword==null?"":keyword,genreId,page,size);}    
    public void create(Track t)throws Exception{validate(t); dao.save(t);}    
    public void update(Track t)throws Exception{ValidationUtil.requirePositive(t.getId(),"Track ID"); validate(t); dao.update(t);}    
    public void delete(int id)throws Exception{ValidationUtil.requirePositive(id,"Track ID"); dao.delete(id);}    
    private void validate(Track t){ValidationUtil.requireNotBlank(t.getName(),"Track name"); ValidationUtil.requirePositive(t.getMediaTypeId(),"Media type ID"); ValidationUtil.requirePositive(t.getMilliseconds(),"Milliseconds"); ValidationUtil.requireNonNegative(t.getUnitPrice(),"Unit price");}
}
