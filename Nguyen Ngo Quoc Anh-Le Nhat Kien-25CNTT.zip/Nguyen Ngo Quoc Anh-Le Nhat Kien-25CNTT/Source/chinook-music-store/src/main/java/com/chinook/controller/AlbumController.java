/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Controller for album actions.
 */

package com.chinook.controller;
import com.chinook.model.Album; import com.chinook.service.AlbumService; import java.util.*;
public class AlbumController { private final AlbumService s; public AlbumController(AlbumService s){this.s=s;} public List<Album> search(String k,int p,int z)throws Exception{return s.search(k,p,z);} public void create(String t,int a)throws Exception{s.create(t,a);} public void update(int id,String t,int a)throws Exception{s.update(id,t,a);} public void delete(int id)throws Exception{s.delete(id);} }
