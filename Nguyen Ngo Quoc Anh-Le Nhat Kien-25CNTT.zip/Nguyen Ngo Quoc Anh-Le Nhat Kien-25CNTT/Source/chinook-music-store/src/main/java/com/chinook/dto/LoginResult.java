/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Immutable DTO returned after successful login.
 */

package com.chinook.dto;
public record LoginResult(String sessionToken, UserDTO user) { }
