/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Profile screen and password change form.
 */

package com.chinook.view;

import com.chinook.dto.UserDTO;
import com.chinook.service.AuthService;
import com.chinook.util.DialogUtil;
import javax.swing.*;
import java.awt.*;

public class ProfilePanel extends JPanel {
    private final String token; private final AuthService auth; private final JPasswordField oldPass=new JPasswordField(16), newPass=new JPasswordField(16);
    public ProfilePanel(String token, UserDTO user, AuthService auth){ this.token=token; this.auth=auth; setLayout(new BorderLayout()); add(info(user),BorderLayout.NORTH); add(change(),BorderLayout.CENTER); }
    private JPanel info(UserDTO u){ JPanel p=new JPanel(new GridLayout(5,2,8,8)); p.setBorder(BorderFactory.createTitledBorder("Profile")); p.add(new JLabel("Username")); p.add(new JLabel(u.username())); p.add(new JLabel("Full name")); p.add(new JLabel(u.fullName())); p.add(new JLabel("Email")); p.add(new JLabel(u.email())); p.add(new JLabel("Role")); p.add(new JLabel(u.role().name())); p.add(new JLabel("Last login")); p.add(new JLabel(String.valueOf(u.lastLogin()))); return p; }
    private JPanel change(){ JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT)); p.setBorder(BorderFactory.createTitledBorder("Change Password")); JButton b=new JButton("Change"); b.addActionListener(e -> { try{ auth.changePassword(token,new String(oldPass.getPassword()),new String(newPass.getPassword())); oldPass.setText(""); newPass.setText(""); DialogUtil.info(this,"Password changed."); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }); p.add(new JLabel("Old:")); p.add(oldPass); p.add(new JLabel("New:")); p.add(newPass); p.add(b); return p; }
}
