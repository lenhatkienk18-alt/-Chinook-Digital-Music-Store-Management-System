/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Singleton configuration for creating JDBC connections.
 */

package com.chinook.config;

import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

/**
 * Singleton pattern.
 * This class stores DB configuration. Each DAO call still opens a fresh Connection.
 */
public final class DatabaseConnection {
    private static DatabaseConnection instance;
    private final String url;
    private final String username;
    private final String password;

    private DatabaseConnection() {
        Properties p = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            if (in != null) p.load(in);
        } catch (Exception ignored) { }
        this.url = p.getProperty("db.url");
        this.username = p.getProperty("db.username");
        this.password = p.getProperty("db.password");
    }

    private DatabaseConnection(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) instance = new DatabaseConnection();
        return instance;
    }

    /** Used by JUnit tests to replace MySQL with an in-memory H2 database. */
    public static synchronized void overrideForTesting(String url, String username, String password) {
        instance = new DatabaseConnection(url, username, password);
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }
}
