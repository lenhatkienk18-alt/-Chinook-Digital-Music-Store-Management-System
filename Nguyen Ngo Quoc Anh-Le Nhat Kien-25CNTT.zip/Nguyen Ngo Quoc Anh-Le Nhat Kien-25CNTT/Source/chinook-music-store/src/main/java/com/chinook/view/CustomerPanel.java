/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Customer CRUD panel with search/filter, JTable sorting, and Excel export.
 */

package com.chinook.view;

import com.chinook.controller.CustomerController;
import com.chinook.event.DataChangeNotifier;
import com.chinook.model.Customer;
import com.chinook.service.ExportService;
import com.chinook.util.DialogUtil;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.io.File; import java.util.List;

public class CustomerPanel extends JPanel {
    private final CustomerController controller; private final ExportService exporter; private final DataChangeNotifier notifier; private final boolean canWrite;
    private final JTextField search=new JTextField(14), countryFilter=new JTextField(10), id=new JTextField(5), first=new JTextField(10), last=new JTextField(10), company=new JTextField(10), city=new JTextField(10), country=new JTextField(10), phone=new JTextField(10), email=new JTextField(16);
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","First","Last","Company","City","Country","Phone","Email"},0); private final JTable table=new JTable(model);
    public CustomerPanel(CustomerController controller, ExportService exporter, DataChangeNotifier notifier, boolean canWrite){
        this.controller=controller; this.exporter=exporter; this.notifier=notifier; this.canWrite=canWrite; setLayout(new BorderLayout(8,8)); add(top(),BorderLayout.NORTH); add(new JScrollPane(table),BorderLayout.CENTER); add(form(),BorderLayout.SOUTH); table.setAutoCreateRowSorter(true); id.setEditable(false); table.getSelectionModel().addListSelectionListener(e->select()); load();
    }
    private JPanel top(){ JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT)); JButton find=new JButton("Search"), refresh=new JButton("Refresh"), export=new JButton("Export Excel"); find.addActionListener(e->load()); refresh.addActionListener(e->{search.setText("");countryFilter.setText("");load();}); export.addActionListener(e->export()); p.add(new JLabel("Keyword:"));p.add(search);p.add(new JLabel("Country:"));p.add(countryFilter);p.add(find);p.add(refresh);p.add(export);return p; }
    private JPanel form(){ JPanel box=new JPanel(new GridLayout(3,1)); JPanel r1=new JPanel(new FlowLayout(FlowLayout.LEFT)); JPanel r2=new JPanel(new FlowLayout(FlowLayout.LEFT)); JPanel r3=new JPanel(new FlowLayout(FlowLayout.LEFT)); r1.add(new JLabel("ID:"));r1.add(id);r1.add(new JLabel("First:"));r1.add(first);r1.add(new JLabel("Last:"));r1.add(last);r1.add(new JLabel("Company:"));r1.add(company); r2.add(new JLabel("City:"));r2.add(city);r2.add(new JLabel("Country:"));r2.add(country);r2.add(new JLabel("Phone:"));r2.add(phone);r2.add(new JLabel("Email:"));r2.add(email); JButton add=new JButton("Add"), update=new JButton("Update"), del=new JButton("Delete"); add.setEnabled(canWrite);update.setEnabled(canWrite);del.setEnabled(canWrite); add.addActionListener(e->add());update.addActionListener(e->update());del.addActionListener(e->delete()); r3.add(add);r3.add(update);r3.add(del); box.add(r1);box.add(r2);box.add(r3);return box; }
    private void load(){ new SwingWorker<List<Customer>,Void>(){ protected List<Customer> doInBackground() throws Exception { return controller.search(search.getText(), countryFilter.getText(),1,50); } protected void done(){ try{ model.setRowCount(0); for(Customer c:get()) model.addRow(new Object[]{c.getId(),c.getFirstName(),c.getLastName(),c.getCompany(),c.getCity(),c.getCountry(),c.getPhone(),c.getEmail()}); }catch(Exception ex){DialogUtil.error(CustomerPanel.this,ex.getMessage());} } }.execute(); }
    private void add(){ try{ controller.create(read(false)); clear(); load(); notifier.notifyDataChanged(); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void update(){ try{ controller.update(read(true)); clear(); load(); notifier.notifyDataChanged(); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void delete(){ try{ int x=Integer.parseInt(id.getText()); if(DialogUtil.confirm(this,"Delete selected customer?")){ controller.delete(x); clear(); load(); notifier.notifyDataChanged(); } }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private Customer read(boolean hasId){ Customer c=new Customer(first.getText(),last.getText(),company.getText(),null,city.getText(),null,country.getText(),null,phone.getText(),email.getText()); if(hasId)c.setId(Integer.parseInt(id.getText())); return c; }
    private void select(){ int r=table.getSelectedRow(); if(r<0)return; int m=table.convertRowIndexToModel(r); id.setText(v(m,0)); first.setText(v(m,1)); last.setText(v(m,2)); company.setText(v(m,3)); city.setText(v(m,4)); country.setText(v(m,5)); phone.setText(v(m,6)); email.setText(v(m,7)); }
    private String v(int r,int c){ Object x=model.getValueAt(r,c); return x==null?"":x.toString(); }
    private void clear(){ id.setText(""); first.setText(""); last.setText(""); company.setText(""); city.setText(""); country.setText(""); phone.setText(""); email.setText(""); }
    private void export(){ try{ File f=new File("customers.xlsx"); exporter.exportTable(table,f,"Customers"); DialogUtil.info(this,"Exported: "+f.getAbsolutePath()); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
}
