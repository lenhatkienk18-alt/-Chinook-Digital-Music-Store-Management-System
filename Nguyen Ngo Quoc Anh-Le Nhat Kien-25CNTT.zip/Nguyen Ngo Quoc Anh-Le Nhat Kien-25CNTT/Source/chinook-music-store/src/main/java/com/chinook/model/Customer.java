/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Domain model for customers.
 */

package com.chinook.model;

public class Customer extends BaseEntity {
    private String firstName, lastName, company, address, city, state, country, postalCode, phone, email;
    public Customer() { }
    public Customer(String firstName, String lastName, String company, String address, String city, String state, String country, String postalCode, String phone, String email) {
        this.firstName = firstName; this.lastName = lastName; this.company = company; this.address = address; this.city = city;
        this.state = state; this.country = country; this.postalCode = postalCode; this.phone = phone; this.email = email;
    }
    public Customer(int id, String firstName, String lastName, String company, String address, String city, String state, String country, String postalCode, String phone, String email) {
        this(firstName,lastName,company,address,city,state,country,postalCode,phone,email); setId(id);
    }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getCompany() { return company; }
    public String getAddress() { return address; }
    public String getCity() { return city; }
    public String getState() { return state; }
    public String getCountry() { return country; }
    public String getPostalCode() { return postalCode; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public void setCompany(String company) { this.company = company; }
    public void setAddress(String address) { this.address = address; }
    public void setCity(String city) { this.city = city; }
    public void setState(String state) { this.state = state; }
    public void setCountry(String country) { this.country = country; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setEmail(String email) { this.email = email; }
}
