/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Immutable DTO for genre sales chart.
 */

package com.chinook.dto;
import java.math.BigDecimal;
public record GenreSalesDTO(String genreName, BigDecimal totalSales, int totalItemsSold) { }
