/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Application error codes.
 */

package com.chinook.exception;
public enum ErrorCode { VALIDATION_ERROR, AUTHENTICATION_FAILED, PERMISSION_DENIED, DATABASE_ERROR, EXPORT_ERROR }
