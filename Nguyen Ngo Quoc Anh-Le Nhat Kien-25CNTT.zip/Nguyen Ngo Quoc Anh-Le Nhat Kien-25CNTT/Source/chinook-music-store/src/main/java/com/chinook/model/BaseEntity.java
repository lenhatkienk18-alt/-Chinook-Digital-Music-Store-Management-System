/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Abstract base class for entities with integer primary keys.
 */

package com.chinook.model;

/** Abstraction: common ID field for Artist, Album, Track, Customer, User. */
public abstract class BaseEntity {
    private int id;
    protected BaseEntity() { }
    protected BaseEntity(int id) { this.id = id; }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}
