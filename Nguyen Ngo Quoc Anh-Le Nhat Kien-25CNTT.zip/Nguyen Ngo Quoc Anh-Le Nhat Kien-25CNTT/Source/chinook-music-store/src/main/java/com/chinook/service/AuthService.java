/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Login, logout, session lookup, and password change business logic.
 */

package com.chinook.service;

import com.chinook.dao.UserDAO;
import com.chinook.dto.*;
import com.chinook.exception.*;
import com.chinook.model.User;
import com.chinook.util.*;
import java.time.LocalDateTime;
import java.util.*;

public class AuthService {
    private final UserDAO userDAO;
    private final SessionService sessionService;
    public AuthService(UserDAO userDAO, SessionService sessionService) { this.userDAO = userDAO; this.sessionService = sessionService; }
    public Optional<LoginResult> login(String username, String password) throws Exception {
        ValidationUtil.requireNotBlank(username, "Username"); ValidationUtil.requireNotBlank(password, "Password");
        Optional<User> found = userDAO.findByUsername(username);
        if(found.isEmpty()) return Optional.empty();
        User user = found.get();
        if(!user.isActive()) throw new AppException(ErrorCode.AUTHENTICATION_FAILED, "Account is disabled.");
        if(!PasswordUtil.matches(password, user.getPasswordHash())) return Optional.empty();
        LocalDateTime now = LocalDateTime.now(); user.setLastLogin(now); userDAO.updateLastLogin(user.getId(), now);
        String token = sessionService.createSession(user);
        return Optional.of(new LoginResult(token, toDTO(user)));
    }
    public void logout(String token) { sessionService.logout(token); }
    public UserDTO getCurrentUserDTO(String token) { return sessionService.getUser(token).map(this::toDTO).orElseThrow(() -> new AppException(ErrorCode.AUTHENTICATION_FAILED, "Session expired.")); }
    public void changePassword(String token, String oldPassword, String newPassword) throws Exception {
        User user = sessionService.getUser(token).orElseThrow(() -> new AppException(ErrorCode.AUTHENTICATION_FAILED, "Session expired."));
        if(!PasswordUtil.matches(oldPassword, user.getPasswordHash())) throw new AppException(ErrorCode.AUTHENTICATION_FAILED, "Old password is incorrect.");
        String hash = PasswordUtil.sha256(newPassword); userDAO.updatePasswordHash(user.getId(), hash); user.setPasswordHash(hash);
    }
    private UserDTO toDTO(User user) { return new UserDTO(user.getId(), user.getUsername(), user.getFullName(), user.getEmail(), user.getRole(), user.getLastLogin()); }
}
