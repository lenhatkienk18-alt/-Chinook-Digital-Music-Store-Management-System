/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: JDBC DAO for Album CRUD.
 */

package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.model.Album;
import java.sql.*;
import java.util.*;

public class AlbumDAO implements CrudDAO<Album, Integer> {
    public Optional<Album> findById(Integer id) throws Exception {
        String sql = "SELECT album_id,title,artist_id FROM albums WHERE album_id=?";
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id); try (ResultSet rs = ps.executeQuery()) { return rs.next()?Optional.of(map(rs)):Optional.empty(); }
        }
    }
    public List<Album> findAll(int page, int pageSize) throws Exception { return searchByTitle("", page, pageSize); }
    public List<Album> searchByTitle(String keyword, int page, int pageSize) throws Exception {
        String sql = "SELECT album_id,title,artist_id FROM albums WHERE title LIKE ? ORDER BY album_id LIMIT ? OFFSET ?";
        List<Album> list = new ArrayList<>(); int offset = (page - 1) * pageSize;
        try (Connection c = DatabaseConnection.getInstance().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%"+keyword+"%"); ps.setInt(2,pageSize); ps.setInt(3,offset);
            try(ResultSet rs=ps.executeQuery()){ while(rs.next()) list.add(map(rs)); }
        }
        return list;
    }
    public void save(Album a) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("INSERT INTO albums(title,artist_id) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,a.getTitle()); ps.setInt(2,a.getArtistId()); ps.executeUpdate(); try(ResultSet k=ps.getGeneratedKeys()){ if(k.next()) a.setId(k.getInt(1)); }
        }
    }
    public void update(Album a) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("UPDATE albums SET title=?, artist_id=? WHERE album_id=?")){
            ps.setString(1,a.getTitle()); ps.setInt(2,a.getArtistId()); ps.setInt(3,a.getId()); ps.executeUpdate();
        }
    }
    public void delete(Integer id) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM albums WHERE album_id=?")){
            ps.setInt(1,id); ps.executeUpdate();
        }
    }
    private Album map(ResultSet rs) throws Exception { return new Album(rs.getInt("album_id"), rs.getString("title"), rs.getInt("artist_id")); }
}
