/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: JDBC DAO for Track CRUD and joined track search.
 */

package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.dto.TrackDTO;
import com.chinook.model.Track;
import java.sql.*;
import java.util.*;

public class TrackDAO implements CrudDAO<Track, Integer> {
    public Optional<Track> findById(Integer id) throws Exception {
        String sql = "SELECT * FROM tracks WHERE track_id=?";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ return rs.next()?Optional.of(mapTrack(rs)):Optional.empty(); }
        }
    }
    public List<Track> findAll(int page, int pageSize) throws Exception {
        String sql = "SELECT * FROM tracks ORDER BY track_id LIMIT ? OFFSET ?";
        List<Track> list = new ArrayList<>(); int offset=(page-1)*pageSize;
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,pageSize); ps.setInt(2,offset); try(ResultSet rs=ps.executeQuery()){ while(rs.next()) list.add(mapTrack(rs)); }
        }
        return list;
    }
    public List<TrackDTO> searchDetails(String keyword, Integer genreId, int page, int pageSize) throws Exception {
        String sql = "SELECT * FROM vw_track_details WHERE track_name LIKE ? AND (? IS NULL OR genre_id=?) ORDER BY track_name LIMIT ? OFFSET ?";
        List<TrackDTO> list = new ArrayList<>(); int offset=(page-1)*pageSize;
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,"%"+keyword+"%");
            if(genreId==null){ ps.setNull(2,Types.INTEGER); ps.setNull(3,Types.INTEGER); } else { ps.setInt(2,genreId); ps.setInt(3,genreId); }
            ps.setInt(4,pageSize); ps.setInt(5,offset);
            try(ResultSet rs=ps.executeQuery()){ while(rs.next()) list.add(mapDTO(rs)); }
        }
        return list;
    }
    public void save(Track t) throws Exception {
        String sql="INSERT INTO tracks(name,album_id,media_type_id,genre_id,composer,milliseconds,bytes,unit_price) VALUES(?,?,?,?,?,?,?,?)";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            setParams(ps,t); ps.executeUpdate(); try(ResultSet k=ps.getGeneratedKeys()){ if(k.next()) t.setId(k.getInt(1)); }
        }
    }
    public void update(Track t) throws Exception {
        String sql="UPDATE tracks SET name=?, album_id=?, media_type_id=?, genre_id=?, composer=?, milliseconds=?, bytes=?, unit_price=? WHERE track_id=?";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            setParams(ps,t); ps.setInt(9,t.getId()); ps.executeUpdate();
        }
    }
    public void delete(Integer id) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM tracks WHERE track_id=?")){
            ps.setInt(1,id); ps.executeUpdate();
        }
    }
    private void setParams(PreparedStatement ps, Track t) throws Exception {
        ps.setString(1,t.getName()); setIntOrNull(ps,2,t.getAlbumId()); ps.setInt(3,t.getMediaTypeId()); setIntOrNull(ps,4,t.getGenreId());
        ps.setString(5,t.getComposer()); ps.setInt(6,t.getMilliseconds()); setIntOrNull(ps,7,t.getBytes()); ps.setBigDecimal(8,t.getUnitPrice());
    }
    private void setIntOrNull(PreparedStatement ps, int index, Integer value) throws Exception { if(value==null) ps.setNull(index,Types.INTEGER); else ps.setInt(index,value); }
    private Integer getIntOrNull(ResultSet rs, String col) throws Exception { int v=rs.getInt(col); return rs.wasNull()?null:v; }
    private Track mapTrack(ResultSet rs) throws Exception { return new Track(rs.getInt("track_id"), rs.getString("name"), getIntOrNull(rs,"album_id"), rs.getInt("media_type_id"), getIntOrNull(rs,"genre_id"), rs.getString("composer"), rs.getInt("milliseconds"), getIntOrNull(rs,"bytes"), rs.getBigDecimal("unit_price")); }
    private TrackDTO mapDTO(ResultSet rs) throws Exception { return new TrackDTO(rs.getInt("track_id"), rs.getString("track_name"), getIntOrNull(rs,"album_id"), rs.getString("album_title"), getIntOrNull(rs,"artist_id"), rs.getString("artist_name"), getIntOrNull(rs,"genre_id"), rs.getString("genre_name"), getIntOrNull(rs,"media_type_id"), rs.getString("media_type"), rs.getString("composer"), rs.getInt("milliseconds"), getIntOrNull(rs,"bytes"), rs.getBigDecimal("unit_price")); }
}
