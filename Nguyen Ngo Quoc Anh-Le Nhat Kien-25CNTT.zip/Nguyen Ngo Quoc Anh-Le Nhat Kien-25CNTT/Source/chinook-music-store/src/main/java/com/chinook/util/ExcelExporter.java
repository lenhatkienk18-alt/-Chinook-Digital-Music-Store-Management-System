/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Exports JTable data to .xlsx using Apache POI.
 */

package com.chinook.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javax.swing.*;
import javax.swing.table.TableModel;
import java.io.*;
import java.time.LocalDateTime;

public final class ExcelExporter {
    private ExcelExporter() { }
    public static void exportTableToXlsx(JTable table, File file, String sheetName) throws Exception {
        TableModel model = table.getModel();
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(sheetName == null ? "Export" : sheetName);
            Font bold = workbook.createFont(); bold.setBold(true);
            CellStyle headerStyle = workbook.createCellStyle(); headerStyle.setFont(bold);

            Row header = sheet.createRow(0);
            for (int c = 0; c < model.getColumnCount(); c++) {
                Cell cell = header.createCell(c); cell.setCellValue(model.getColumnName(c)); cell.setCellStyle(headerStyle);
            }
            for (int r = 0; r < model.getRowCount(); r++) {
                Row row = sheet.createRow(r + 1);
                for (int c = 0; c < model.getColumnCount(); c++) {
                    Object value = model.getValueAt(r, c);
                    row.createCell(c).setCellValue(value == null ? "" : value.toString());
                }
            }
            Row summary = sheet.createRow(model.getRowCount() + 2);
            summary.createCell(0).setCellValue("Exported at");
            summary.createCell(1).setCellValue(LocalDateTime.now().toString());
            summary.createCell(2).setCellValue("Total rows");
            summary.createCell(3).setCellValue(model.getRowCount());
            for (int c = 0; c < model.getColumnCount(); c++) sheet.autoSizeColumn(c);
            try (FileOutputStream out = new FileOutputStream(file)) { workbook.write(out); }
        }
    }
}
