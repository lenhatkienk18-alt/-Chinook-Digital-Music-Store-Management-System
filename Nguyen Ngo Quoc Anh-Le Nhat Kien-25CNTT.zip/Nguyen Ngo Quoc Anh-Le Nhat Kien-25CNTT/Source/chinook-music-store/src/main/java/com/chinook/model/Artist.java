/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Domain model for music artists.
 */

package com.chinook.model;

public class Artist extends BaseEntity {
    private String name;
    public Artist() { }
    public Artist(String name) { this.name = name; }
    public Artist(int id, String name) { super(id); this.name = name; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
