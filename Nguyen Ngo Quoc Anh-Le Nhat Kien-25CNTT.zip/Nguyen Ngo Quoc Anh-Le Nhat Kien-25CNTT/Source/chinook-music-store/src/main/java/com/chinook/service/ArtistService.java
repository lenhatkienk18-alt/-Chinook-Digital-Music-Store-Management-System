/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Business service for Artist validation and CRUD.
 */

package com.chinook.service;
import com.chinook.dao.ArtistDAO; import com.chinook.model.Artist; import com.chinook.util.ValidationUtil; import java.util.*;
public class ArtistService {
    private final ArtistDAO dao; public ArtistService(ArtistDAO dao){this.dao=dao;}
    public List<Artist> search(String keyword,int page,int size)throws Exception{return dao.searchByName(keyword==null?"":keyword,page,size);}    
    public void create(String name)throws Exception{ValidationUtil.requireNotBlank(name,"Artist name"); dao.save(new Artist(name.trim()));}
    public void update(int id,String name)throws Exception{ValidationUtil.requirePositive(id,"Artist ID"); ValidationUtil.requireNotBlank(name,"Artist name"); dao.update(new Artist(id,name.trim()));}
    public void delete(int id)throws Exception{ValidationUtil.requirePositive(id,"Artist ID"); dao.delete(id);} 
}
