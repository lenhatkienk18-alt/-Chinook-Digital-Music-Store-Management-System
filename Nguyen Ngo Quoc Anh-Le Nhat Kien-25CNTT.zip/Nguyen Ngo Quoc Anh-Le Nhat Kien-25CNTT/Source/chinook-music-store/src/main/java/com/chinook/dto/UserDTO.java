/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Immutable DTO for user profile data.
 */

package com.chinook.dto;
import com.chinook.model.Role;
import java.time.LocalDateTime;
public record UserDTO(int id, String username, String fullName, String email, Role role, LocalDateTime lastLogin) { }
