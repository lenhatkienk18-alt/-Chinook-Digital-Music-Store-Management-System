/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Domain model for tracks.
 */

package com.chinook.model;

import java.math.BigDecimal;

public class Track extends BaseEntity {
    private String name;
    private Integer albumId;
    private int mediaTypeId;
    private Integer genreId;
    private String composer;
    private int milliseconds;
    private Integer bytes;
    private BigDecimal unitPrice;

    public Track() { }
    public Track(String name, Integer albumId, int mediaTypeId, Integer genreId, String composer, int milliseconds, Integer bytes, BigDecimal unitPrice) {
        this.name = name; this.albumId = albumId; this.mediaTypeId = mediaTypeId; this.genreId = genreId;
        this.composer = composer; this.milliseconds = milliseconds; this.bytes = bytes; this.unitPrice = unitPrice;
    }
    public Track(int id, String name, Integer albumId, int mediaTypeId, Integer genreId, String composer, int milliseconds, Integer bytes, BigDecimal unitPrice) {
        this(name, albumId, mediaTypeId, genreId, composer, milliseconds, bytes, unitPrice); setId(id);
    }
    public String getName() { return name; }
    public Integer getAlbumId() { return albumId; }
    public int getMediaTypeId() { return mediaTypeId; }
    public Integer getGenreId() { return genreId; }
    public String getComposer() { return composer; }
    public int getMilliseconds() { return milliseconds; }
    public Integer getBytes() { return bytes; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setName(String name) { this.name = name; }
    public void setAlbumId(Integer albumId) { this.albumId = albumId; }
    public void setMediaTypeId(int mediaTypeId) { this.mediaTypeId = mediaTypeId; }
    public void setGenreId(Integer genreId) { this.genreId = genreId; }
    public void setComposer(String composer) { this.composer = composer; }
    public void setMilliseconds(int milliseconds) { this.milliseconds = milliseconds; }
    public void setBytes(Integer bytes) { this.bytes = bytes; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
}
