/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Manages login sessions using HashMap<String, User>.
 */

package com.chinook.service;

import com.chinook.model.*;
import java.util.*;

public class SessionService {
    private final Map<String, User> sessions = new HashMap<>();
    public String createSession(User user) { String token = UUID.randomUUID().toString(); sessions.put(token, user); return token; }
    public Optional<User> getUser(String token) { return Optional.ofNullable(sessions.get(token)); }
    public void logout(String token) { sessions.remove(token); }
    public boolean canWrite(Role role) {
        return switch (role) { case ADMIN, STAFF -> true; case VIEWER -> false; };
    }
}
