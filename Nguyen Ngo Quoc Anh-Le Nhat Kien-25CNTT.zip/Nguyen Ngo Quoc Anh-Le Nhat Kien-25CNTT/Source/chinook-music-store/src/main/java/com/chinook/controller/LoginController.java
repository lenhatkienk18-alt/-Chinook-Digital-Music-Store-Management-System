/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Controller for login actions.
 */

package com.chinook.controller;
import com.chinook.dto.LoginResult; import com.chinook.service.AuthService; import java.util.*;
public class LoginController { private final AuthService service; public LoginController(AuthService service){this.service=service;} public Optional<LoginResult> login(String u,String p)throws Exception{return service.login(u,p);} }
