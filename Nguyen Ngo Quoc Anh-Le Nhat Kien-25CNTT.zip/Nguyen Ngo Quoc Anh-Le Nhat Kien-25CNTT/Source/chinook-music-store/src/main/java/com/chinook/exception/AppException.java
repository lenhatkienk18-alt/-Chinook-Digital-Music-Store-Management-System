/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Custom runtime exception with an error code.
 */

package com.chinook.exception;

public class AppException extends RuntimeException {
    private final ErrorCode errorCode;
    public AppException(ErrorCode errorCode, String message) { super(message); this.errorCode = errorCode; }
    public AppException(ErrorCode errorCode, String message, Throwable cause) { super(message, cause); this.errorCode = errorCode; }
    public ErrorCode getErrorCode() { return errorCode; }
}
