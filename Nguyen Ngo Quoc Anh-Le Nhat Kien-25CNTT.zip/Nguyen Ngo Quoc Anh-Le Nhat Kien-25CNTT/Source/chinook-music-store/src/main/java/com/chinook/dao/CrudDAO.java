/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Generic DAO interface for CRUD operations.
 */

package com.chinook.dao;
import java.util.*;
public interface CrudDAO<T, ID> {
    Optional<T> findById(ID id) throws Exception;
    List<T> findAll(int page, int pageSize) throws Exception;
    void save(T entity) throws Exception;
    void update(T entity) throws Exception;
    void delete(ID id) throws Exception;
}
