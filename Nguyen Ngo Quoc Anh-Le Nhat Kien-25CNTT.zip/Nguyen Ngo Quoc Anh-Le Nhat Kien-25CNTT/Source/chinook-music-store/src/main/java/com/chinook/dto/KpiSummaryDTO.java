/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Immutable DTO for dashboard KPI summary.
 */

package com.chinook.dto;
import java.math.BigDecimal;
public record KpiSummaryDTO(int totalTracks, int totalCustomers, int totalInvoices, BigDecimal totalRevenue, BigDecimal averageInvoiceValue) { }
