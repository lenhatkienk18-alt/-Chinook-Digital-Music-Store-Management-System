/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Artist CRUD panel with search, JTable sorting, and Excel export.
 */

package com.chinook.view;

import com.chinook.controller.ArtistController;
import com.chinook.event.DataChangeNotifier;
import com.chinook.model.Artist;
import com.chinook.service.ExportService;
import com.chinook.util.DialogUtil;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.io.File; import java.util.List;

public class ArtistPanel extends JPanel {
    private final ArtistController controller; private final ExportService exporter; private final DataChangeNotifier notifier; private final boolean canWrite;
    private final JTextField search=new JTextField(18), id=new JTextField(6), name=new JTextField(24);
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","Name"},0); private final JTable table=new JTable(model);
    public ArtistPanel(ArtistController controller, ExportService exporter, DataChangeNotifier notifier, boolean canWrite){
        this.controller=controller; this.exporter=exporter; this.notifier=notifier; this.canWrite=canWrite; setLayout(new BorderLayout(8,8));
        add(top(),BorderLayout.NORTH); add(new JScrollPane(table),BorderLayout.CENTER); add(form(),BorderLayout.SOUTH); table.setAutoCreateRowSorter(true); id.setEditable(false); table.getSelectionModel().addListSelectionListener(e->select()); load();
    }
    private JPanel top(){ JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT)); JButton find=new JButton("Search"), refresh=new JButton("Refresh"), export=new JButton("Export Excel"); find.addActionListener(e->load()); refresh.addActionListener(e->{search.setText(""); load();}); export.addActionListener(e->export()); p.add(new JLabel("Keyword:")); p.add(search); p.add(find); p.add(refresh); p.add(export); return p; }
    private JPanel form(){ JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT)); JButton add=new JButton("Add"), update=new JButton("Update"), del=new JButton("Delete"); add.setEnabled(canWrite); update.setEnabled(canWrite); del.setEnabled(canWrite); add.addActionListener(e->add()); update.addActionListener(e->update()); del.addActionListener(e->delete()); p.add(new JLabel("ID:")); p.add(id); p.add(new JLabel("Name:")); p.add(name); p.add(add); p.add(update); p.add(del); return p; }
    private void load(){ new SwingWorker<List<Artist>,Void>(){ protected List<Artist> doInBackground() throws Exception { return controller.search(search.getText(),1,50); } protected void done(){ try{ model.setRowCount(0); for(Artist a:get()) model.addRow(new Object[]{a.getId(),a.getName()}); }catch(Exception ex){DialogUtil.error(ArtistPanel.this,ex.getMessage());} } }.execute(); }
    private void add(){ try{ controller.create(name.getText()); clear(); load(); notifier.notifyDataChanged(); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void update(){ try{ controller.update(Integer.parseInt(id.getText()), name.getText()); clear(); load(); notifier.notifyDataChanged(); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void delete(){ try{ int x=Integer.parseInt(id.getText()); if(DialogUtil.confirm(this,"Delete selected artist?")){ controller.delete(x); clear(); load(); notifier.notifyDataChanged(); } }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
    private void select(){ int r=table.getSelectedRow(); if(r<0)return; int m=table.convertRowIndexToModel(r); id.setText(String.valueOf(model.getValueAt(m,0))); name.setText(String.valueOf(model.getValueAt(m,1))); }
    private void clear(){ id.setText(""); name.setText(""); }
    private void export(){ try{ File f=new File("artists.xlsx"); exporter.exportTable(table,f,"Artists"); DialogUtil.info(this,"Exported: "+f.getAbsolutePath()); }catch(Exception ex){DialogUtil.error(this,ex.getMessage());} }
}
