/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Controller for customer actions.
 */

package com.chinook.controller;
import com.chinook.model.Customer; import com.chinook.service.CustomerService; import java.util.*;
public class CustomerController { private final CustomerService s; public CustomerController(CustomerService s){this.s=s;} public List<Customer> search(String k,String c,int p,int z)throws Exception{return s.search(k,c,p,z);} public void create(Customer c)throws Exception{s.create(c);} public void update(Customer c)throws Exception{s.update(c);} public void delete(int id)throws Exception{s.delete(id);} }
