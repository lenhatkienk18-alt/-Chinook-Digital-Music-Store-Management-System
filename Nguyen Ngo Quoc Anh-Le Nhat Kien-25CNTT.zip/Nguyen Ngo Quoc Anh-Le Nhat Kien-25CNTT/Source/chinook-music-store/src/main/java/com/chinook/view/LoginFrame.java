/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Swing login window for authentication.
 */

package com.chinook.view;

import com.chinook.controller.LoginController;
import com.chinook.dao.UserDAO;
import com.chinook.service.*;
import com.chinook.util.DialogUtil;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField usernameField = new JTextField("admin", 20);
    private final JPasswordField passwordField = new JPasswordField("admin123", 20);
    private final SessionService sessionService = new SessionService();
    private final AuthService authService = new AuthService(new UserDAO(), sessionService);
    private final LoginController controller = new LoginController(authService);

    public LoginFrame() {
        setTitle("Chinook Music Store - Login"); setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(430,240); setLocationRelativeTo(null);
        setLayout(new BorderLayout(8,8)); add(title(), BorderLayout.NORTH); add(form(), BorderLayout.CENTER); add(buttons(), BorderLayout.SOUTH);
    }
    private JPanel title(){ JPanel p=new JPanel(); JLabel l=new JLabel("Chinook Music Store Management System"); l.setFont(l.getFont().deriveFont(Font.BOLD,16f)); p.add(l); return p; }
    private JPanel form(){ JPanel p=new JPanel(new GridLayout(2,2,8,8)); p.setBorder(BorderFactory.createEmptyBorder(20,30,10,30)); p.add(new JLabel("Username:")); p.add(usernameField); p.add(new JLabel("Password:")); p.add(passwordField); return p; }
    private JPanel buttons(){ JPanel p=new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton b=new JButton("Login"); b.addActionListener(e -> login()); p.add(b); return p; }
    private void login(){
        try {
            var result = controller.login(usernameField.getText(), new String(passwordField.getPassword()));
            if(result.isEmpty()){ DialogUtil.error(this,"Invalid username or password."); return; }
            new MainFrame(result.get().sessionToken(), result.get().user(), authService, sessionService).setVisible(true); dispose();
        } catch(Exception ex){ DialogUtil.error(this, ex.getMessage()); }
    }
}
