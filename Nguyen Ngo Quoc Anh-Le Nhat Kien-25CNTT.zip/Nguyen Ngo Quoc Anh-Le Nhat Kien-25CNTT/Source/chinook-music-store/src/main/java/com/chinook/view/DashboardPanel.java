/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Dashboard with KPI strip and JFreeChart visualizations.
 */

package com.chinook.view;

import com.chinook.controller.DashboardController;
import com.chinook.dto.*;
import com.chinook.event.DataChangeListener;
import com.chinook.util.DialogUtil;
import org.jfree.chart.*;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DashboardPanel extends JPanel implements DataChangeListener {
    private final DashboardController controller;
    private final JLabel tracks=new JLabel("Tracks: -"), customers=new JLabel("Customers: -"), invoices=new JLabel("Invoices: -"), revenue=new JLabel("Revenue: -"), avg=new JLabel("Avg: -");
    private final JPanel charts = new JPanel(new GridLayout(1,2,8,8));
    public DashboardPanel(DashboardController controller){ this.controller=controller; setLayout(new BorderLayout(8,8)); add(kpis(),BorderLayout.NORTH); add(charts,BorderLayout.CENTER); refresh(); }
    private JPanel kpis(){ JPanel p=new JPanel(new GridLayout(1,5,8,8)); for(JLabel l: new JLabel[]{tracks,customers,invoices,revenue,avg}){ l.setHorizontalAlignment(SwingConstants.CENTER); l.setBorder(BorderFactory.createEtchedBorder()); l.setFont(l.getFont().deriveFont(Font.BOLD,14f)); p.add(l);} return p; }
    public void refresh(){
        new SwingWorker<Data,Void>(){
            protected Data doInBackground() throws Exception { return new Data(controller.getKpiSummary(), controller.getMonthlyRevenue(), controller.getTopGenres(5)); }
            protected void done(){ try{ render(get()); }catch(Exception e){ DialogUtil.error(DashboardPanel.this,e.getMessage()); } }
        }.execute();
    }
    private void render(Data d){ tracks.setText("Tracks: "+d.kpi.totalTracks()); customers.setText("Customers: "+d.kpi.totalCustomers()); invoices.setText("Invoices: "+d.kpi.totalInvoices()); revenue.setText("Revenue: $"+d.kpi.totalRevenue()); avg.setText("Avg: $"+d.kpi.averageInvoiceValue()); charts.removeAll(); charts.add(revenueChart(d.revenue)); charts.add(genreChart(d.genres)); charts.revalidate(); charts.repaint(); }
    private ChartPanel revenueChart(List<RevenueDTO> data){ DefaultCategoryDataset ds=new DefaultCategoryDataset(); for(RevenueDTO r:data) ds.addValue(r.totalRevenue(),"Revenue",r.month()); return new ChartPanel(ChartFactory.createLineChart("Monthly Revenue","Month","Revenue",ds)); }
    private ChartPanel genreChart(List<GenreSalesDTO> data){ DefaultCategoryDataset ds=new DefaultCategoryDataset(); for(GenreSalesDTO g:data) ds.addValue(g.totalSales(),"Sales",g.genreName()); return new ChartPanel(ChartFactory.createBarChart("Top Genres by Sales","Genre","Sales",ds)); }
    public void onDataChanged(){ refresh(); }
    private record Data(KpiSummaryDTO kpi, List<RevenueDTO> revenue, List<GenreSalesDTO> genres){}
}
