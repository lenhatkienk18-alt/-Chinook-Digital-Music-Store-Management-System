/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Small Swing helper for consistent dialogs.
 */

package com.chinook.util;
import javax.swing.*;
import java.awt.*;
public final class DialogUtil {
    private DialogUtil() { }
    public static void info(Component parent, String message) { JOptionPane.showMessageDialog(parent, message, "Information", JOptionPane.INFORMATION_MESSAGE); }
    public static void error(Component parent, String message) { JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE); }
    public static boolean confirm(Component parent, String message) { return JOptionPane.showConfirmDialog(parent, message, "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION; }
}
