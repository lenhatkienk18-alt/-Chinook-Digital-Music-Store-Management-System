/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: JDBC DAO for Customer CRUD.
 */

package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.model.Customer;
import java.sql.*;
import java.util.*;

public class CustomerDAO implements CrudDAO<Customer, Integer> {
    public Optional<Customer> findById(Integer id) throws Exception {
        String sql="SELECT * FROM customers WHERE customer_id=?";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ return rs.next()?Optional.of(map(rs)):Optional.empty(); }
        }
    }
    public List<Customer> findAll(int page, int pageSize) throws Exception { return search("", null, page, pageSize); }
    public List<Customer> search(String keyword, String country, int page, int pageSize) throws Exception {
        String sql="SELECT * FROM customers WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?) AND (? IS NULL OR country=?) ORDER BY customer_id LIMIT ? OFFSET ?";
        List<Customer> list=new ArrayList<>(); int offset=(page-1)*pageSize; String like="%"+keyword+"%";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,like); ps.setString(2,like); ps.setString(3,like);
            if(country==null || country.isBlank()){ ps.setNull(4,Types.VARCHAR); ps.setNull(5,Types.VARCHAR); } else { ps.setString(4,country); ps.setString(5,country); }
            ps.setInt(6,pageSize); ps.setInt(7,offset); try(ResultSet rs=ps.executeQuery()){ while(rs.next()) list.add(map(rs)); }
        }
        return list;
    }
    public void save(Customer x) throws Exception {
        String sql="INSERT INTO customers(first_name,last_name,company,address,city,state,country,postal_code,phone,email) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            params(ps,x); ps.executeUpdate(); try(ResultSet k=ps.getGeneratedKeys()){ if(k.next()) x.setId(k.getInt(1)); }
        }
    }
    public void update(Customer x) throws Exception {
        String sql="UPDATE customers SET first_name=?,last_name=?,company=?,address=?,city=?,state=?,country=?,postal_code=?,phone=?,email=? WHERE customer_id=?";
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            params(ps,x); ps.setInt(11,x.getId()); ps.executeUpdate();
        }
    }
    public void delete(Integer id) throws Exception {
        try(Connection c=DatabaseConnection.getInstance().getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM customers WHERE customer_id=?")){
            ps.setInt(1,id); ps.executeUpdate();
        }
    }
    private void params(PreparedStatement ps, Customer x) throws Exception {
        ps.setString(1,x.getFirstName()); ps.setString(2,x.getLastName()); ps.setString(3,x.getCompany()); ps.setString(4,x.getAddress()); ps.setString(5,x.getCity()); ps.setString(6,x.getState()); ps.setString(7,x.getCountry()); ps.setString(8,x.getPostalCode()); ps.setString(9,x.getPhone()); ps.setString(10,x.getEmail());
    }
    private Customer map(ResultSet rs) throws Exception { return new Customer(rs.getInt("customer_id"), rs.getString("first_name"), rs.getString("last_name"), rs.getString("company"), rs.getString("address"), rs.getString("city"), rs.getString("state"), rs.getString("country"), rs.getString("postal_code"), rs.getString("phone"), rs.getString("email")); }
}
