/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Business service for Customer validation, search, filter, and CRUD.
 */

package com.chinook.service;
import com.chinook.dao.CustomerDAO; import com.chinook.model.Customer; import com.chinook.util.ValidationUtil; import java.util.*;
public class CustomerService {
    private final CustomerDAO dao; public CustomerService(CustomerDAO dao){this.dao=dao;}
    public List<Customer> search(String keyword,String country,int page,int size)throws Exception{return dao.search(keyword==null?"":keyword,country,page,size);}    
    public void create(Customer c)throws Exception{validate(c); dao.save(c);}    
    public void update(Customer c)throws Exception{ValidationUtil.requirePositive(c.getId(),"Customer ID"); validate(c); dao.update(c);}    
    public void delete(int id)throws Exception{ValidationUtil.requirePositive(id,"Customer ID"); dao.delete(id);}    
    private void validate(Customer c){ValidationUtil.requireNotBlank(c.getFirstName(),"First name"); ValidationUtil.requireNotBlank(c.getLastName(),"Last name"); ValidationUtil.requireEmail(c.getEmail());}
}
