/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Role enum for role-based access control.
 */

package com.chinook.model;
public enum Role { ADMIN, STAFF, VIEWER }
