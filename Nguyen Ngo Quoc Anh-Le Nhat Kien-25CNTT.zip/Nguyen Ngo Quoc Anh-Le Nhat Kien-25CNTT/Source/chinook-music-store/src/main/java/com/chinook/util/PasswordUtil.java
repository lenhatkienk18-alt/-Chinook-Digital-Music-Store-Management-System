/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: SHA-256 password hashing utility.
 */

package com.chinook.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class PasswordUtil {
    private PasswordUtil() { }
    public static String sha256(String rawPassword) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(rawPassword.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte b : bytes) builder.append(String.format("%02x", b));
            return builder.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Cannot hash password", e);
        }
    }
    public static boolean matches(String rawPassword, String storedHash) {
        return rawPassword != null && storedHash != null && sha256(rawPassword).equalsIgnoreCase(storedHash);
    }
}
