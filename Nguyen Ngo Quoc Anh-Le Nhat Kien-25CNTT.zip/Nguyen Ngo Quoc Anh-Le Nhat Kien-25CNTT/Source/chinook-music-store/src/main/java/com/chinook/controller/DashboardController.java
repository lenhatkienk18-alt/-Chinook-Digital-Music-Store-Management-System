/*
 * Author: Nguyen Ngo Quoc Anh
 * Date: 2026-05-28
 * Purpose: Controller for dashboard data.
 */

package com.chinook.controller;
import com.chinook.dto.*; import com.chinook.service.DashboardService; import java.util.*;
public class DashboardController { private final DashboardService s; public DashboardController(DashboardService s){this.s=s;} public KpiSummaryDTO getKpiSummary()throws Exception{return s.getKpiSummary();} public List<RevenueDTO> getMonthlyRevenue()throws Exception{return s.getMonthlyRevenue();} public List<GenreSalesDTO> getTopGenres(int limit)throws Exception{return s.getTopGenres(limit);} }
