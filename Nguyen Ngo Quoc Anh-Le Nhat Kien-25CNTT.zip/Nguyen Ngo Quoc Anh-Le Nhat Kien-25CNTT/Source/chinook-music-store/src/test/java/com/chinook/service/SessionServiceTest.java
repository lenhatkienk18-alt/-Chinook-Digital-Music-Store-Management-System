package com.chinook.service;

import com.chinook.model.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SessionServiceTest {
    @Test void createSessionShouldStoreUser() {
        SessionService service = new SessionService();
        User user = new User(1, "admin", "hash", "Admin", "admin@test.com", Role.ADMIN, true, null);
        String token = service.createSession(user);
        assertTrue(service.getUser(token).isPresent());
    }
    @Test void viewerShouldNotWrite() {
        assertFalse(new SessionService().canWrite(Role.VIEWER));
    }
}
