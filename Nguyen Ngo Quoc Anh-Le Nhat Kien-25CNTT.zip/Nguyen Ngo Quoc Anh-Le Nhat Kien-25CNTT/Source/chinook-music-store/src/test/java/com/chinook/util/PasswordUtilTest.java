package com.chinook.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PasswordUtilTest {
    @Test void sha256ShouldReturn64HexCharacters() {
        String hash = PasswordUtil.sha256("admin123");
        assertEquals(64, hash.length());
        assertTrue(hash.matches("[a-f0-9]+"));
    }
    @Test void matchesShouldAcceptCorrectPassword() {
        String hash = PasswordUtil.sha256("staff123");
        assertTrue(PasswordUtil.matches("staff123", hash));
    }
}
