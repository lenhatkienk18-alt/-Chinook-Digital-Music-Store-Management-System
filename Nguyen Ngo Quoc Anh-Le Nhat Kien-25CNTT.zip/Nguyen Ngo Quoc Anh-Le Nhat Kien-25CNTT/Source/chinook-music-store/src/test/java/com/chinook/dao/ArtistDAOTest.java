package com.chinook.dao;

import com.chinook.config.DatabaseConnection;
import com.chinook.model.Artist;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ArtistDAOTest {
    private ArtistDAO dao;

    @BeforeEach void setUp() throws Exception {
        DatabaseConnection.overrideForTesting("jdbc:h2:mem:chinook_test;MODE=MySQL;DB_CLOSE_DELAY=-1", "sa", "");
        try (var c = DatabaseConnection.getInstance().getConnection(); var st = c.createStatement()) {
            st.execute("DROP ALL OBJECTS");
            st.execute("CREATE TABLE artists (artist_id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL UNIQUE)");
        }
        dao = new ArtistDAO();
    }

    @Test void saveAndFindByIdShouldWork() throws Exception {
        Artist artist = new Artist("Test Artist");
        dao.save(artist);
        assertTrue(artist.getId() > 0);
        assertEquals("Test Artist", dao.findById(artist.getId()).get().getName());
    }

    @Test void updateShouldChangeArtistName() throws Exception {
        Artist artist = new Artist("Old Name");
        dao.save(artist);
        artist.setName("New Name");
        dao.update(artist);
        assertEquals("New Name", dao.findById(artist.getId()).get().getName());
    }

    @Test void deleteShouldRemoveArtist() throws Exception {
        Artist artist = new Artist("Delete Me");
        dao.save(artist);
        dao.delete(artist.getId());
        assertTrue(dao.findById(artist.getId()).isEmpty());
    }
}
