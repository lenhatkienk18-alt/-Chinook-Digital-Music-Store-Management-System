package com.chinook.test;

import static org.junit.jupiter.api.Assertions.*;
import com.chinook.config.DatabaseConnection;
import org.junit.jupiter.api.Test;

public class ChinookAppTest {

    @Test
    public void testDatabaseConnectionSingleton() throws Exception {
        DatabaseConnection instance1 = DatabaseConnection.getInstance();
        DatabaseConnection instance2 = DatabaseConnection.getInstance();

        assertNotNull(instance1, "Database connection registry instance should not be null");
        assertSame(instance1, instance2, "DatabaseConnection instances must reference the exact same object instance");
    }
}