package com.chinook.util;

import com.chinook.exception.AppException;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class ValidationUtilTest {
    @Test void requireNotBlankShouldThrowForBlankText() {
        assertThrows(AppException.class, () -> ValidationUtil.requireNotBlank(" ", "Name"));
    }
    @Test void requireEmailShouldAcceptValidEmail() {
        assertDoesNotThrow(() -> ValidationUtil.requireEmail("test@example.com"));
    }
    @Test void requireNonNegativeShouldRejectNegativeNumber() {
        assertThrows(AppException.class, () -> ValidationUtil.requireNonNegative(new BigDecimal("-1"), "Price"));
    }
}
